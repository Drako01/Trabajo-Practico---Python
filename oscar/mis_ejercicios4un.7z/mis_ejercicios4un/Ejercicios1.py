""" Ejercicio 1 (Dificultad media)
Escribir un programa que tome el valor del nombre del usuario por consola
 y luego lo imprima en pantalla.
 """

nombre = input("Ingrese su nombre: ")


def saludo(i):

    return f"Hola {i}!"


print(saludo(nombre))
